import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo';

// null sur iOS ou dans Expo Go : l'appli fonctionne alors sans les fonctions Android
export default Platform.OS === 'android' ? requireOptionalNativeModule('PochetteNative') : null;
