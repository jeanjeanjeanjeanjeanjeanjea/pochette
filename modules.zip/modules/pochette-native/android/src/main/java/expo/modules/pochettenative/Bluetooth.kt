package expo.modules.pochettenative

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaRouter2
import android.os.Build
import android.provider.Settings

/**
 * Bluetooth : liste des appareils, recherche, appairage et accès au panneau « Sortie audio ».
 * Android ne permet pas à une appli de connecter elle-même une enceinte ni de diffuser
 * sur plusieurs : c'est le panneau système (Dual Audio chez Samsung) qui s'en charge.
 */
@SuppressLint("MissingPermission")
object Bluetooth {
  @Volatile private var a2dp: BluetoothA2dp? = null
  @Volatile private var headset: BluetoothHeadset? = null
  private var receiver: BroadcastReceiver? = null
  var onEvent: ((Map<String, Any?>) -> Unit)? = null

  private val profileListener = object : BluetoothProfile.ServiceListener {
    override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
      when (profile) {
        BluetoothProfile.A2DP -> a2dp = proxy as? BluetoothA2dp
        BluetoothProfile.HEADSET -> headset = proxy as? BluetoothHeadset
      }
      onEvent?.invoke(mapOf("type" to "changed"))
    }

    override fun onServiceDisconnected(profile: Int) {
      when (profile) {
        BluetoothProfile.A2DP -> a2dp = null
        BluetoothProfile.HEADSET -> headset = null
      }
    }
  }

  fun adapter(ctx: Context): BluetoothAdapter? =
    ctx.getSystemService(BluetoothManager::class.java)?.adapter

  private fun granted(ctx: Context, perm: String) =
    ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

  fun canConnect(ctx: Context) = Build.VERSION.SDK_INT < 31 || granted(ctx, Manifest.permission.BLUETOOTH_CONNECT)
  fun canScan(ctx: Context) = Build.VERSION.SDK_INT < 31 || granted(ctx, Manifest.permission.BLUETOOTH_SCAN)

  private fun ensureProxies(ctx: Context) {
    val ad = adapter(ctx) ?: return
    if (!canConnect(ctx)) return
    val app = ctx.applicationContext
    if (a2dp == null) runCatching { ad.getProfileProxy(app, profileListener, BluetoothProfile.A2DP) }
    if (headset == null) runCatching { ad.getProfileProxy(app, profileListener, BluetoothProfile.HEADSET) }
  }

  fun state(ctx: Context): Map<String, Any?> {
    val ad = adapter(ctx)
    return mapOf(
      "supported" to (ad != null),
      "enabled" to (ad?.isEnabled == true),
      "permission" to (canConnect(ctx) && canScan(ctx)),
      "scanning" to (canScan(ctx) && ad?.isDiscovering == true),
    )
  }

  fun kind(d: BluetoothDevice): String {
    val cls = runCatching { d.bluetoothClass }.getOrNull() ?: return "other"
    return when (cls.deviceClass) {
      BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER,
      BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO,
      BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO -> "speaker"
      BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES,
      BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET,
      BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE -> "headphones"
      BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO -> "car"
      BluetoothClass.Device.AUDIO_VIDEO_VIDEO_DISPLAY_AND_LOUDSPEAKER -> "tv"
      else -> when (cls.majorDeviceClass) {
        BluetoothClass.Device.Major.AUDIO_VIDEO -> "audio"
        BluetoothClass.Device.Major.WEARABLE -> "watch"
        BluetoothClass.Device.Major.PHONE -> "phone"
        BluetoothClass.Device.Major.COMPUTER -> "computer"
        BluetoothClass.Device.Major.PERIPHERAL -> "peripheral"
        else -> "other"
      }
    }
  }

  /** Adresses des appareils Bluetooth qui jouent actuellement la musique. */
  private fun activeOutputs(ctx: Context): Set<String> {
    if (Build.VERSION.SDK_INT < 28) return emptySet()
    val am = ctx.getSystemService(AudioManager::class.java) ?: return emptySet()
    val btTypes = mutableSetOf(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)
    if (Build.VERSION.SDK_INT >= 31) { btTypes += AudioDeviceInfo.TYPE_BLE_HEADSET; btTypes += AudioDeviceInfo.TYPE_BLE_SPEAKER }
    if (Build.VERSION.SDK_INT >= 33) btTypes += AudioDeviceInfo.TYPE_BLE_BROADCAST
    val devices: List<AudioDeviceInfo> = if (Build.VERSION.SDK_INT >= 33) {
      val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build()
      runCatching { am.getAudioDevicesForAttributes(attrs) }.getOrNull() ?: emptyList()
    } else {
      am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
    }
    return devices.filter { it.type in btTypes }.map { it.address.uppercase() }.toSet()
  }

  private fun describe(d: BluetoothDevice, connected: Set<String>, active: Set<String>): Map<String, Any?> {
    val addr = d.address.uppercase()
    val name = runCatching { d.name }.getOrNull()
    return mapOf(
      "address" to d.address,
      "name" to (if (name.isNullOrBlank()) d.address else name),
      "kind" to kind(d),
      "paired" to (runCatching { d.bondState }.getOrNull() == BluetoothDevice.BOND_BONDED),
      "pairing" to (runCatching { d.bondState }.getOrNull() == BluetoothDevice.BOND_BONDING),
      "connected" to (addr in connected || addr in active),
      "active" to (addr in active),
    )
  }

  fun pairedDevices(ctx: Context): List<Map<String, Any?>> {
    val ad = adapter(ctx) ?: return emptyList()
    if (!canConnect(ctx)) return emptyList()
    ensureProxies(ctx)
    val connected = mutableSetOf<String>()
    runCatching { a2dp?.connectedDevices?.forEach { connected += it.address.uppercase() } }
    runCatching { headset?.connectedDevices?.forEach { connected += it.address.uppercase() } }
    val active = runCatching { activeOutputs(ctx) }.getOrDefault(emptySet())
    val bonded = runCatching { ad.bondedDevices?.toList() }.getOrNull() ?: emptyList()
    return bonded.map { describe(it, connected, active) }
  }

  fun startScan(ctx: Context): Boolean {
    val ad = adapter(ctx) ?: return false
    if (!canScan(ctx) || !ad.isEnabled) return false
    register(ctx)
    return runCatching {
      if (ad.isDiscovering) ad.cancelDiscovery()
      ad.startDiscovery()
    }.getOrDefault(false)
  }

  fun stopScan(ctx: Context) {
    val ad = adapter(ctx) ?: return
    if (canScan(ctx)) runCatching { ad.cancelDiscovery() }
  }

  fun pair(ctx: Context, address: String): Boolean {
    val ad = adapter(ctx) ?: return false
    if (!canConnect(ctx)) return false
    return runCatching {
      if (canScan(ctx)) ad.cancelDiscovery()
      ad.getRemoteDevice(address).createBond()
    }.getOrDefault(false)
  }

  fun requestEnable(ctx: Context) {
    runCatching {
      ctx.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure { openSettings(ctx) }
  }

  fun openSettings(ctx: Context) {
    runCatching {
      ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
  }

  /** Ouvre le panneau « Sortie audio » du système ; sinon les réglages Bluetooth. */
  fun openOutputSwitcher(ctx: Context): Boolean {
    if (Build.VERSION.SDK_INT >= 34) {
      val ok = runCatching { MediaRouter2.getInstance(ctx).showSystemOutputSwitcher() }.getOrDefault(false)
      if (ok) return true
    }
    openSettings(ctx)
    return false
  }

  /** Écoute les changements (appareil trouvé, appairé, connecté, Bluetooth activé…). */
  fun register(ctx: Context) {
    if (receiver != null) return
    val app = ctx.applicationContext
    val r = object : BroadcastReceiver() {
      override fun onReceive(c: Context, intent: Intent) {
        when (intent.action) {
          BluetoothDevice.ACTION_FOUND -> {
            val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
              intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            } else {
              @Suppress("DEPRECATION") intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
            }
            if (d != null) onEvent?.invoke(mapOf("type" to "found", "device" to describe(d, emptySet(), emptySet())))
          }
          BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> onEvent?.invoke(mapOf("type" to "scanFinished"))
          else -> onEvent?.invoke(mapOf("type" to "changed"))
        }
      }
    }
    val f = IntentFilter().apply {
      addAction(BluetoothDevice.ACTION_FOUND)
      addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
      addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
      addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
      addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
      addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
      addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
      addAction(BluetoothA2dp.ACTION_PLAYING_STATE_CHANGED)
      addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
      addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
    }
    if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(r, f, Context.RECEIVER_EXPORTED)
    else app.registerReceiver(r, f)
    receiver = r
  }
}
