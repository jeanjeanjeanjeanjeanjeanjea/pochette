package expo.modules.pochettenative

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Service activé par l'utilisateur dans « Accès aux notifications ».
 * Il ne lit aucune notification : il sert uniquement à suivre les sessions média
 * (Spotify ou autre lecteur) pour connaître le morceau en cours et sa pochette.
 */
class NowPlayingListenerService : NotificationListenerService() {
  companion object {
    const val SPOTIFY = "com.spotify.music"
    @Volatile var instance: NowPlayingListenerService? = null
    private val artLoader = Executors.newSingleThreadExecutor()
  }

  private val main = Handler(Looper.getMainLooper())
  private var msm: MediaSessionManager? = null
  private val callbacks = LinkedHashMap<MediaController, MediaController.Callback>()
  private var artCache: Pair<String, Bitmap>? = null
  // Évite de redimensionner la même image à chaque lecture / pause
  private var lastRawArt: Bitmap? = null
  private var lastScaledArt: Bitmap? = null
  private var loadingKey: String? = null

  private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
    attach(list ?: emptyList())
  }

  override fun onListenerConnected() {
    super.onListenerConnected()
    instance = this
    val m = getSystemService(MediaSessionManager::class.java) ?: return
    msm = m
    try {
      val cn = Access.listenerComponent(this)
      m.addOnActiveSessionsChangedListener(sessionsListener, cn, main)
      attach(m.getActiveSessions(cn))
    } catch (_: SecurityException) {
    }
  }

  override fun onListenerDisconnected() {
    runCatching { msm?.removeOnActiveSessionsChangedListener(sessionsListener) }
    detachAll()
    if (instance === this) instance = null
    super.onListenerDisconnected()
  }

  override fun onDestroy() {
    detachAll()
    if (instance === this) instance = null
    super.onDestroy()
  }

  /** Appelé quand un réglage change (ex. source Spotify / toutes les applis). */
  fun refreshFromOutside() { main.post { refresh() } }

  private fun attach(list: List<MediaController>) {
    detachAll()
    for (c in list) {
      val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
        override fun onSessionDestroyed() = refresh()
      }
      runCatching { c.registerCallback(cb, main); callbacks[c] = cb }
    }
    refresh()
  }

  private fun detachAll() {
    for ((c, cb) in callbacks) runCatching { c.unregisterCallback(cb) }
    callbacks.clear()
  }

  private fun refresh() {
    val onlySpotify = Prefs.source(this) == "spotify"
    val candidates = callbacks.keys.filter { c ->
      (!onlySpotify || c.packageName == SPOTIFY) && c.metadata != null
    }
    val chosen = candidates.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
      ?: candidates.firstOrNull()
    NowPlayingStore.controller = chosen
    if (chosen == null) { NowPlayingStore.publish(this, null); return }

    val md = chosen.metadata ?: return
    val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
      ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
    val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
      ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
      ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
    val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
    val key = listOf(chosen.packageName, title, artist, album).joinToString("|")
    val playing = chosen.playbackState?.state == PlaybackState.STATE_PLAYING

    var art: Bitmap? = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
      ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
      ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

    if (art != null) {
      if (art !== lastRawArt) {
        lastRawArt = art
        lastScaledArt = Bitmaps.limit(art, 1024)
      }
      art = lastScaledArt
    } else {
      val cached = artCache
      if (cached != null && cached.first == key) {
        art = cached.second
      } else {
        val uri = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
          ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
          ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
        if (uri != null && loadingKey != key) loadArtAsync(key, uri)
      }
    }

    NowPlayingStore.publish(
      this,
      NowPlaying(key, title, artist, album, art, playing, chosen.packageName),
    )
  }

  private fun loadArtAsync(key: String, uri: String) {
    loadingKey = key
    artLoader.execute {
      val bmp = runCatching { loadBitmap(uri) }.getOrNull()?.let { Bitmaps.limit(it, 1024) }
      main.post {
        loadingKey = null
        if (bmp != null) {
          artCache = key to bmp
          if (NowPlayingStore.current?.key == key) refresh()
        }
      }
    }
  }

  private fun loadBitmap(uri: String): Bitmap? {
    val u = Uri.parse(uri)
    return when (u.scheme) {
      "http", "https" -> {
        val conn = URL(uri).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        try { conn.inputStream.use { BitmapFactory.decodeStream(it) } } finally { conn.disconnect() }
      }
      "content", "file", "android.resource" ->
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
      else -> null
    }
  }
}
