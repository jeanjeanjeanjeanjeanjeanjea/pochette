package expo.modules.pochettenative

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class PochetteNativeModule : Module() {
  private val context: Context
    get() = requireNotNull(appContext.reactContext) { "Contexte Android indisponible" }

  private val listener: (NowPlaying?) -> Unit = { np ->
    sendEvent("onNowPlaying", mapOf("track" to NowPlayingStore.toMap(np)))
  }

  override fun definition() = ModuleDefinition {
    Name("PochetteNative")

    Events("onNowPlaying", "onBluetooth")

    OnCreate {
      Bluetooth.onEvent = { e -> runCatching { sendEvent("onBluetooth", e) } }
      runCatching { Bluetooth.register(context) }
    }
    OnDestroy { Bluetooth.onEvent = null }
    OnStartObserving { NowPlayingStore.addListener(listener) }
    OnStopObserving { NowPlayingStore.removeListener(listener) }

    Function("hasNotificationAccess") { Access.hasNotificationAccess(context) }
    Function("openNotificationAccessSettings") { Access.openNotificationAccessSettings(context) }
    Function("openAppDetails") { Access.openAppDetails(context) }
    Function("openScreenSaverSettings") { Access.openScreenSaverSettings(context) }

    Function("getNowPlaying") { NowPlayingStore.toMap(NowPlayingStore.current) }

    Function("getSettings") { Prefs.toMap(context) }
    Function("setSettings") { values: Map<String, Any?> ->
      val ctx = context
      Prefs.update(ctx, values)
      Access.requestRebind(ctx)
      NowPlayingListenerService.instance?.refreshFromOutside()
      WidgetUpdater.updateAll(ctx)
      if (values["wallpaperEnabled"] == true || values.containsKey("wallpaperStyle") || values.containsKey("wallpaperTarget")) {
        WallpaperUpdater.schedule(ctx, 300)
      }
      Prefs.toMap(ctx)
    }

    AsyncFunction("applyWallpaperNow") { WallpaperUpdater.applyNow(context) }

    Function("requestPinWidget") { kind: String -> WidgetUpdater.requestPin(context, kind) }

    // ----- Bluetooth -----
    Function("btState") { Bluetooth.state(context) }
    Function("btDevices") {
      runCatching { Bluetooth.register(context) }
      Bluetooth.pairedDevices(context)
    }
    Function("btStartScan") { Bluetooth.startScan(context) }
    Function("btStopScan") { Bluetooth.stopScan(context) }
    Function("btPair") { address: String -> Bluetooth.pair(context, address) }
    Function("btEnable") { Bluetooth.requestEnable(context) }
    Function("btOpenSettings") { Bluetooth.openSettings(context) }
    // Le panneau « Sortie audio » doit être ouvert depuis le fil principal d'Android
    AsyncFunction("btOpenOutput") {
      val ctx = context
      Handler(Looper.getMainLooper()).post { Bluetooth.openOutputSwitcher(ctx) }
      true
    }

    // Mode Always-On : écran maintenu allumé et luminosité au minimum
    AsyncFunction("setAodWindow") { enabled: Boolean ->
      val activity = appContext.currentActivity ?: return@AsyncFunction false
      activity.runOnUiThread {
        val w = activity.window
        val lp = w.attributes
        lp.screenBrightness = if (enabled) 0.02f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        w.attributes = lp
        if (enabled) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
      }
      true
    }
  }
}
