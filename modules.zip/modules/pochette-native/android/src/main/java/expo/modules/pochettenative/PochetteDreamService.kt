package expo.modules.pochettenative

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.os.Handler
import android.os.Looper
import android.service.dreams.DreamService
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.TextView
import kotlin.random.Random

/**
 * Économiseur d'écran Android : horloge + pochette sur fond noir, faible luminosité.
 * Se lance automatiquement pendant la charge si on le choisit dans les réglages Android.
 */
class PochetteDreamService : DreamService() {
  private val main = Handler(Looper.getMainLooper())
  private var content: View? = null
  private var spinner: ObjectAnimator? = null
  private val listener: (NowPlaying?) -> Unit = { np -> main.post { render(np) } }

  // Anti-marquage : le bloc se déplace doucement chaque minute
  private val drift = object : Runnable {
    override fun run() {
      content?.let { v ->
        val parent = v.parent as? View
        if (parent != null && parent.width > 0) {
          val maxX = ((parent.width - v.width) / 2f * 0.8f).coerceAtLeast(0f)
          val maxY = ((parent.height - v.height) / 2f * 0.8f).coerceAtLeast(0f)
          v.animate()
            .translationX((Random.nextFloat() * 2 - 1) * maxX)
            .translationY((Random.nextFloat() * 2 - 1) * maxY)
            .setDuration(3000)
            .start()
        }
      }
      main.postDelayed(this, 60_000)
    }
  }

  override fun onAttachedToWindow() {
    super.onAttachedToWindow()
    isInteractive = false
    isFullscreen = true
    isScreenBright = false
    setContentView(R.layout.pochette_dream)
    content = findViewById(R.id.pochette_dream_content)
    render(NowPlayingStore.current)
    NowPlayingStore.addListener(listener)
    main.postDelayed(drift, 60_000)
  }

  override fun onDetachedFromWindow() {
    NowPlayingStore.removeListener(listener)
    main.removeCallbacks(drift)
    spinner?.cancel()
    spinner = null
    super.onDetachedFromWindow()
  }

  private fun render(np: NowPlaying?) {
    val cover = findViewById<ImageView>(R.id.pochette_dream_cover) ?: return
    val title = findViewById<TextView>(R.id.pochette_dream_title)
    val artist = findViewById<TextView>(R.id.pochette_dream_artist)
    val art = np?.art
    val vinyl = Prefs.dreamStyle(this) == "vinyl"
    when {
      vinyl && np != null -> {
        cover.setImageBitmap(Bitmaps.vinyl(art, 600))
        cover.visibility = View.VISIBLE
      }
      art != null -> {
        cover.setImageBitmap(Bitmaps.rounded(art, 540, 0.04f))
        cover.visibility = View.VISIBLE
      }
      else -> cover.visibility = View.GONE
    }

    // Le vinyle tourne pendant la lecture (33 tours = 1,8 s par tour) et s'arrête en pause
    if (vinyl && np?.isPlaying == true) {
      val s = spinner
      if (s == null) {
        spinner = ObjectAnimator.ofFloat(cover, View.ROTATION, cover.rotation, cover.rotation + 360f).apply {
          duration = 1800
          repeatCount = ValueAnimator.INFINITE
          interpolator = LinearInterpolator()
          start()
        }
      } else if (s.isPaused) {
        s.resume()
      }
    } else if (vinyl) {
      spinner?.pause()
    } else {
      spinner?.cancel()
      spinner = null
      cover.rotation = 0f
    }
    title?.text = np?.title ?: ""
    artist?.text = np?.artist ?: ""
  }
}
