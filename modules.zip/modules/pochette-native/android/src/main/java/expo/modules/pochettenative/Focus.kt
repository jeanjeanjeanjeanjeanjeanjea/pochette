package expo.modules.pochettenative

import android.app.AlarmManager
import android.app.AutomaticZenRule
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.service.notification.Condition

/**
 * Mode « Pochette – Travail » : un mode Ne pas déranger propre à l'appli,
 * activé pendant les sessions du minuteur. L'utilisateur peut le personnaliser
 * dans les réglages Android (applis et contacts autorisés).
 */
object Focus {
  private const val PREFS = "pochette_native"
  private const val RULE_KEY = "focusRuleId"
  private val CONDITION: Uri = Uri.parse("condition://expo.modules.pochettenative/focus")

  private fun nm(ctx: Context) = ctx.getSystemService(NotificationManager::class.java)

  fun hasAccess(ctx: Context) = nm(ctx)?.isNotificationPolicyAccessGranted == true

  fun openAccessSettings(ctx: Context) {
    runCatching {
      ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
  }

  private fun ruleId(ctx: Context): String? {
    val nm = nm(ctx) ?: return null
    val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val existing = sp.getString(RULE_KEY, null)
    if (existing != null && runCatching { nm.getAutomaticZenRule(existing) }.getOrNull() != null) return existing
    val activity = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.component
    val rule = AutomaticZenRule(
      "Pochette – Travail", null, activity, CONDITION, null,
      NotificationManager.INTERRUPTION_FILTER_PRIORITY, true,
    )
    val id = runCatching { nm.addAutomaticZenRule(rule) }.getOrNull() ?: return null
    sp.edit().putString(RULE_KEY, id).apply()
    return id
  }

  /** Active ou coupe le mode. endAt (ms) : coupure automatique de secours, même appli fermée. */
  fun set(ctx: Context, on: Boolean, endAt: Long): Boolean {
    val nm = nm(ctx) ?: return false
    if (!hasAccess(ctx)) return false
    val ok = if (Build.VERSION.SDK_INT >= 29) {
      val id = ruleId(ctx) ?: return false
      val state = if (on) Condition.STATE_TRUE else Condition.STATE_FALSE
      runCatching {
        nm.setAutomaticZenRuleState(id, Condition(CONDITION, if (on) "Session de travail" else "Terminé", state))
      }.isSuccess
    } else {
      runCatching {
        nm.setInterruptionFilter(
          if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL,
        )
      }.isSuccess
    }
    scheduleOff(ctx, if (on) endAt else 0L)
    return ok
  }

  private fun scheduleOff(ctx: Context, at: Long) {
    val am = ctx.getSystemService(AlarmManager::class.java) ?: return
    val pi = PendingIntent.getBroadcast(
      ctx, 7301, Intent(ctx, FocusEndReceiver::class.java),
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )
    am.cancel(pi)
    if (at > System.currentTimeMillis()) runCatching { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) }
  }
}

/** Coupe le mode à la fin de la session si l'appli n'était plus ouverte. */
class FocusEndReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    Focus.set(context, false, 0L)
  }
}
