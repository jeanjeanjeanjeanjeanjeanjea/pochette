package expo.modules.pochettenative

import android.content.Context

/** Réglages partagés entre l'appli, le service, les widgets et le fond d'écran. */
object Prefs {
  private const val NAME = "pochette_native"

  private val DEFAULTS: Map<String, Any> = mapOf(
    "wallpaperEnabled" to false,
    "wallpaperTarget" to "lock",   // home | lock | both
    "wallpaperStyle" to "blur",    // blur | fill
    "source" to "spotify",         // spotify | all
    "dreamStyle" to "cover",       // cover | vinyl
  )

  private fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

  fun wallpaperEnabled(ctx: Context) = sp(ctx).getBoolean("wallpaperEnabled", false)
  fun wallpaperTarget(ctx: Context) = sp(ctx).getString("wallpaperTarget", "lock") ?: "lock"
  fun wallpaperStyle(ctx: Context) = sp(ctx).getString("wallpaperStyle", "blur") ?: "blur"
  fun source(ctx: Context) = sp(ctx).getString("source", "spotify") ?: "spotify"
  fun dreamStyle(ctx: Context) = sp(ctx).getString("dreamStyle", "cover") ?: "cover"

  fun toMap(ctx: Context): Map<String, Any?> = mapOf(
    "wallpaperEnabled" to wallpaperEnabled(ctx),
    "wallpaperTarget" to wallpaperTarget(ctx),
    "wallpaperStyle" to wallpaperStyle(ctx),
    "source" to source(ctx),
    "dreamStyle" to dreamStyle(ctx),
  )

  fun update(ctx: Context, values: Map<String, Any?>) {
    val e = sp(ctx).edit()
    for ((k, v) in values) {
      if (!DEFAULTS.containsKey(k)) continue
      when (v) {
        is Boolean -> e.putBoolean(k, v)
        is String -> e.putString(k, v)
      }
    }
    e.apply()
  }
}
