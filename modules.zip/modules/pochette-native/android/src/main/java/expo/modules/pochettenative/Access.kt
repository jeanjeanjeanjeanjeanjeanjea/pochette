package expo.modules.pochettenative

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService

object Access {
  fun listenerComponent(ctx: Context) = ComponentName(ctx, NowPlayingListenerService::class.java)

  fun hasNotificationAccess(ctx: Context): Boolean {
    if (Build.VERSION.SDK_INT >= 27) {
      val nm = ctx.getSystemService(NotificationManager::class.java) ?: return false
      return nm.isNotificationListenerAccessGranted(listenerComponent(ctx))
    }
    val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
    return flat.contains(ctx.packageName)
  }

  fun requestRebind(ctx: Context) {
    if (!hasNotificationAccess(ctx)) return
    runCatching { NotificationListenerService.requestRebind(listenerComponent(ctx)) }
  }

  fun openNotificationAccessSettings(ctx: Context) {
    val direct = if (Build.VERSION.SDK_INT >= 30) {
      Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
        .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, listenerComponent(ctx).flattenToString())
    } else null
    val fallback = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
    start(ctx, direct, fallback)
  }

  fun openAppDetails(ctx: Context) {
    start(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)), null)
  }

  fun openScreenSaverSettings(ctx: Context) {
    start(ctx, Intent(Settings.ACTION_DREAM_SETTINGS), Intent(Settings.ACTION_DISPLAY_SETTINGS))
  }

  private fun start(ctx: Context, first: Intent?, fallback: Intent?) {
    for (i in listOfNotNull(first, fallback)) {
      try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return
      } catch (_: Exception) {
      }
    }
  }
}
