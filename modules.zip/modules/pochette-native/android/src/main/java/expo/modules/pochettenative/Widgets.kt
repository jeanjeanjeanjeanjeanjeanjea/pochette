package expo.modules.pochettenative

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.RemoteViews

/** Widget carré : la pochette seule. */
class CoverWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
    Access.requestRebind(context)
    WidgetUpdater.updateAll(context)
  }
}

/** Widget large : pochette, titre, artiste et commandes. */
class NowPlayingWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
    Access.requestRebind(context)
    WidgetUpdater.updateAll(context)
  }
}

/** Boutons précédent / lecture-pause / suivant du widget. */
class WidgetActionReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val tc = NowPlayingStore.controller?.transportControls ?: return
    when (intent.action) {
      WidgetUpdater.ACTION_PREV -> tc.skipToPrevious()
      WidgetUpdater.ACTION_NEXT -> tc.skipToNext()
      WidgetUpdater.ACTION_TOGGLE ->
        if (NowPlayingStore.current?.isPlaying == true) tc.pause() else tc.play()
    }
  }
}

object WidgetUpdater {
  const val ACTION_PREV = "expo.modules.pochettenative.PREV"
  const val ACTION_TOGGLE = "expo.modules.pochettenative.TOGGLE"
  const val ACTION_NEXT = "expo.modules.pochettenative.NEXT"

  fun updateAll(ctx: Context) {
    val mgr = AppWidgetManager.getInstance(ctx) ?: return
    val np = NowPlayingStore.current
    val access = Access.hasNotificationAccess(ctx)

    val coverIds = mgr.getAppWidgetIds(ComponentName(ctx, CoverWidgetProvider::class.java))
    if (coverIds.isNotEmpty()) mgr.updateAppWidget(coverIds, coverViews(ctx, np, access))

    val npIds = mgr.getAppWidgetIds(ComponentName(ctx, NowPlayingWidgetProvider::class.java))
    if (npIds.isNotEmpty()) mgr.updateAppWidget(npIds, nowPlayingViews(ctx, np, access))
  }

  fun requestPin(ctx: Context, kind: String): Boolean {
    if (Build.VERSION.SDK_INT < 26) return false
    val mgr = AppWidgetManager.getInstance(ctx) ?: return false
    if (!mgr.isRequestPinAppWidgetSupported) return false
    val cls = if (kind == "cover") CoverWidgetProvider::class.java else NowPlayingWidgetProvider::class.java
    return mgr.requestPinAppWidget(ComponentName(ctx, cls), null, null)
  }

  private fun coverViews(ctx: Context, np: NowPlaying?, access: Boolean): RemoteViews {
    val v = RemoteViews(ctx.packageName, R.layout.pochette_widget_cover)
    val art = np?.art
    if (art != null) {
      v.setImageViewBitmap(R.id.pochette_cover_img, Bitmaps.rounded(art, 480, 0.06f))
      v.setViewVisibility(R.id.pochette_cover_hint, View.GONE)
    } else {
      v.setImageViewResource(R.id.pochette_cover_img, R.drawable.pochette_placeholder)
      v.setViewVisibility(R.id.pochette_cover_hint, View.VISIBLE)
      v.setTextViewText(
        R.id.pochette_cover_hint,
        ctx.getString(if (access) R.string.pochette_nothing_playing else R.string.pochette_tap_to_setup),
      )
    }
    v.setOnClickPendingIntent(R.id.pochette_cover_root, openIntent(ctx, access))
    return v
  }

  private fun nowPlayingViews(ctx: Context, np: NowPlaying?, access: Boolean): RemoteViews {
    val v = RemoteViews(ctx.packageName, R.layout.pochette_widget_np)
    val art = np?.art
    if (art != null) v.setImageViewBitmap(R.id.pochette_np_cover, Bitmaps.rounded(art, 288, 0.06f))
    else v.setImageViewResource(R.id.pochette_np_cover, R.drawable.pochette_placeholder)

    if (np != null) {
      v.setTextViewText(R.id.pochette_np_title, np.title)
      v.setTextViewText(R.id.pochette_np_artist, listOf(np.artist, np.album).filter { it.isNotBlank() }.joinToString(" — "))
      v.setViewVisibility(R.id.pochette_np_controls, View.VISIBLE)
    } else {
      v.setTextViewText(
        R.id.pochette_np_title,
        ctx.getString(if (access) R.string.pochette_nothing_playing else R.string.pochette_tap_to_setup),
      )
      v.setTextViewText(R.id.pochette_np_artist, "")
      v.setViewVisibility(R.id.pochette_np_controls, if (access) View.VISIBLE else View.GONE)
    }
    v.setImageViewResource(
      R.id.pochette_np_toggle,
      if (np?.isPlaying == true) R.drawable.pochette_ic_pause else R.drawable.pochette_ic_play,
    )
    v.setOnClickPendingIntent(R.id.pochette_np_root, openIntent(ctx, access))
    v.setOnClickPendingIntent(R.id.pochette_np_prev, actionIntent(ctx, ACTION_PREV))
    v.setOnClickPendingIntent(R.id.pochette_np_toggle, actionIntent(ctx, ACTION_TOGGLE))
    v.setOnClickPendingIntent(R.id.pochette_np_next, actionIntent(ctx, ACTION_NEXT))
    return v
  }

  /** Toucher le widget ouvre le lecteur (Spotify) s'il est connu, sinon Pochette. */
  private fun openIntent(ctx: Context, access: Boolean): PendingIntent {
    if (access) NowPlayingStore.controller?.sessionActivity?.let { return it }
    val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
      ?: Intent().setPackage(ctx.packageName)
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    return PendingIntent.getActivity(
      ctx, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )
  }

  private fun actionIntent(ctx: Context, action: String): PendingIntent {
    val i = Intent(ctx, WidgetActionReceiver::class.java).setAction(action)
    return PendingIntent.getBroadcast(
      ctx, action.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )
  }
}
