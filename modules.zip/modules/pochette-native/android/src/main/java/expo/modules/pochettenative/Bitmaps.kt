package expo.modules.pochettenative

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import kotlin.math.max
import kotlin.math.min

object Bitmaps {
  /** Les bitmaps « matériels » ne peuvent pas être dessinés sur un Canvas logiciel. */
  fun software(src: Bitmap): Bitmap {
    if (Build.VERSION.SDK_INT >= 26 && src.config == Bitmap.Config.HARDWARE) {
      return src.copy(Bitmap.Config.ARGB_8888, false)
    }
    return src
  }

  fun limit(src: Bitmap, maxSide: Int): Bitmap {
    val b = software(src)
    val side = max(b.width, b.height)
    if (side <= maxSide) return b
    val k = maxSide.toFloat() / side
    return Bitmap.createScaledBitmap(b, max(1, (b.width * k).toInt()), max(1, (b.height * k).toInt()), true)
  }

  fun squareCrop(src: Bitmap, size: Int): Bitmap {
    val b = software(src)
    val s = min(b.width, b.height)
    val crop = Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s)
    return Bitmap.createScaledBitmap(crop, size, size, true)
  }

  /** Disque vinyle noir avec sillons, reflets et la pochette en étiquette centrale. */
  fun vinyl(art: Bitmap?, size: Int): Bitmap {
    val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    val cx = size / 2f
    val r = size / 2f
    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    fill.color = Color.rgb(14, 14, 14)
    c.drawCircle(cx, cx, r, fill)

    val groove = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeWidth = max(1f, size / 400f)
      color = Color.argb(30, 255, 255, 255)
    }
    var k = 0.96f
    while (k > 0.44f) { c.drawCircle(cx, cx, r * k, groove); k -= 0.035f }

    val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeWidth = r * 0.5f
      color = Color.argb(24, 255, 255, 255)
    }
    val oval = RectF(cx - r * 0.72f, cx - r * 0.72f, cx + r * 0.72f, cx + r * 0.72f)
    c.drawArc(oval, 200f, 50f, false, sheen)
    c.drawArc(oval, 20f, 50f, false, sheen)

    val labelR = r * 0.4f
    if (art != null) {
      val sq = squareCrop(art, max(1, (labelR * 2).toInt()))
      val lp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
      lp.shader = BitmapShader(sq, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
      c.save()
      c.translate(cx - labelR, cx - labelR)
      c.drawCircle(labelR, labelR, labelR, lp)
      c.restore()
    } else {
      fill.color = Color.rgb(60, 60, 60)
      c.drawCircle(cx, cx, labelR, fill)
    }
    fill.color = Color.BLACK
    c.drawCircle(cx, cx, r * 0.035f, fill)
    return out
  }

  fun rounded(src: Bitmap, size: Int, radiusFraction: Float): Bitmap {
    val sq = squareCrop(src, size)
    if (radiusFraction <= 0f) return sq
    val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    paint.shader = BitmapShader(sq, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    val r = size * radiusFraction
    Canvas(out).drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, paint)
    return out
  }
}
