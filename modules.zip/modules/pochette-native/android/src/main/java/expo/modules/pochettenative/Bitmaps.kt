package expo.modules.pochettenative

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import kotlin.math.max
import kotlin.math.min

object Bitmaps {
  /** Les bitmaps « matériels » ne peuvent pas être dessinés sur un Canvas logiciel. */
  fun software(src: Bitmap): Bitmap {
    if (Build.VERSION.SDK_INT >= 26 && src.config == Bitmap.Config.HARDWARE) {
      return src.copy(Bitmap.Config.ARGB_8888, false)
    }
    return src
  }

  fun limit(src: Bitmap, maxSide: Int): Bitmap {
    val b = software(src)
    val side = max(b.width, b.height)
    if (side <= maxSide) return b
    val k = maxSide.toFloat() / side
    return Bitmap.createScaledBitmap(b, max(1, (b.width * k).toInt()), max(1, (b.height * k).toInt()), true)
  }

  fun squareCrop(src: Bitmap, size: Int): Bitmap {
    val b = software(src)
    val s = min(b.width, b.height)
    val crop = Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s)
    return Bitmap.createScaledBitmap(crop, size, size, true)
  }

  fun rounded(src: Bitmap, size: Int, radiusFraction: Float): Bitmap {
    val sq = squareCrop(src, size)
    if (radiusFraction <= 0f) return sq
    val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    paint.shader = BitmapShader(sq, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    val r = size * radiusFraction
    Canvas(out).drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, paint)
    return out
  }
}
