package expo.modules.pochettenative

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.HandlerThread
import android.view.Display
import kotlin.math.max
import kotlin.math.min

/** Compose et applique le fond d'écran à partir de la pochette en cours. */
object WallpaperUpdater {
  private val thread = HandlerThread("pochette-wallpaper").apply { start() }
  private val handler = Handler(thread.looper)

  /** Attend un peu : si on enchaîne les morceaux, seul le dernier est appliqué. */
  fun schedule(ctx: Context, delayMs: Long = 1500) {
    val app = ctx.applicationContext
    handler.removeCallbacksAndMessages(null)
    handler.postDelayed({ applyNow(app) }, delayMs)
  }

  fun applyNow(ctx: Context): Boolean {
    if (!Prefs.wallpaperEnabled(ctx)) return false
    val art = NowPlayingStore.current?.art ?: return false
    return try {
      val (w, h) = screenSize(ctx)
      val bmp = compose(art, w, h, Prefs.wallpaperStyle(ctx))
      val flags = when (Prefs.wallpaperTarget(ctx)) {
        "home" -> WallpaperManager.FLAG_SYSTEM
        "lock" -> WallpaperManager.FLAG_LOCK
        else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
      }
      WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, flags)
      true
    } catch (_: Exception) {
      false
    }
  }

  @Suppress("DEPRECATION")
  private fun screenSize(ctx: Context): Pair<Int, Int> {
    val p = Point()
    val dm = ctx.getSystemService(DisplayManager::class.java)
    val display = dm?.getDisplay(Display.DEFAULT_DISPLAY)
    if (display != null) display.getRealSize(p)
    if (p.x <= 0 || p.y <= 0) {
      val m = ctx.resources.displayMetrics
      p.set(m.widthPixels, m.heightPixels)
    }
    return min(p.x, p.y) to max(p.x, p.y) // toujours en portrait
  }

  private fun compose(art: Bitmap, w: Int, h: Int, style: String): Bitmap {
    val src = Bitmaps.software(art)
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    val filter = Paint(Paint.FILTER_BITMAP_FLAG)
    val side = max(w, h).toFloat()
    val bgRect = RectF((w - side) / 2f, (h - side) / 2f, (w + side) / 2f, (h + side) / 2f)

    if (style == "fill") {
      // Pochette en plein écran (recadrée au centre)
      c.drawBitmap(src, null, bgRect, filter)
      return out
    }

    // Fond flouté : réduction extrême puis agrandissement lissé
    val tiny = Bitmap.createScaledBitmap(src, 12, 12, true)
    val soft = Bitmap.createScaledBitmap(tiny, 96, 96, true)
    c.drawBitmap(soft, null, bgRect, filter)
    c.drawColor(Color.argb(110, 0, 0, 0))

    if (style == "vinyl") {
      val vs = (min(w, h) * 0.86f).toInt()
      val vl = (w - vs) / 2f
      val vt = h * 0.47f - vs / 2f
      val vShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        setShadowLayer(vs * 0.05f, 0f, vs * 0.02f, Color.argb(170, 0, 0, 0))
      }
      c.drawCircle(vl + vs / 2f, vt + vs / 2f, vs / 2f, vShadow)
      c.drawBitmap(Bitmaps.vinyl(src, vs), vl, vt, filter)
      return out
    }

    // Pochette nette au centre, avec ombre
    val size = (min(w, h) * 0.78f).toInt()
    val left = (w - size) / 2f
    val top = h * 0.47f - size / 2f
    val radius = size * 0.035f
    val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.BLACK
      setShadowLayer(size * 0.06f, 0f, size * 0.025f, Color.argb(170, 0, 0, 0))
    }
    c.drawRoundRect(RectF(left, top, left + size, top + size), radius, radius, shadow)
    c.drawBitmap(Bitmaps.rounded(src, size, 0.035f), left, top, filter)
    return out
  }
}
