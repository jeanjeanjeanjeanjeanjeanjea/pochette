package expo.modules.pochettenative

import android.content.Context
import android.graphics.Bitmap
import android.media.session.MediaController
import java.util.concurrent.CopyOnWriteArraySet

data class NowPlaying(
  val key: String,
  val title: String,
  val artist: String,
  val album: String,
  val art: Bitmap?,
  val isPlaying: Boolean,
  val packageName: String,
)

/** Dernier morceau connu, partagé dans tout le processus. */
object NowPlayingStore {
  @Volatile var current: NowPlaying? = null
    private set

  @Volatile var controller: MediaController? = null

  private val listeners = CopyOnWriteArraySet<(NowPlaying?) -> Unit>()

  fun addListener(l: (NowPlaying?) -> Unit) { listeners.add(l) }
  fun removeListener(l: (NowPlaying?) -> Unit) { listeners.remove(l) }

  fun publish(ctx: Context, np: NowPlaying?) {
    val prev = current
    if (prev == np) return
    current = np
    val app = ctx.applicationContext
    for (l in listeners) runCatching { l(np) }
    runCatching { WidgetUpdater.updateAll(app) }
    // Fond d'écran : seulement quand la pochette change (pas à chaque lecture / pause)
    val artChanged = np?.art != null && (prev?.key != np.key || prev.art == null)
    if (artChanged) WallpaperUpdater.schedule(app)
  }

  fun toMap(np: NowPlaying?): Map<String, Any?>? = np?.let {
    mapOf(
      "title" to it.title,
      "artist" to it.artist,
      "album" to it.album,
      "isPlaying" to it.isPlaying,
      "packageName" to it.packageName,
      "hasArt" to (it.art != null),
    )
  }
}
